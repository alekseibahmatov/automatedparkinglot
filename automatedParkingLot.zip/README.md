<h2>How to start this project:</h2>
<ul>
    <li>Open project and link gradle project</li>
    <li>Start the project</li>
    <li>Now it will be available at <b>localhost:8080</b></li>
</ul>
<h2>Endpoints:</h2>
<ul>
    <li>localhost:8080/parking/parkcar/manual?height=CAR_HEIGHT&weight=CAR_WEIGHT</li>
    <li>localhost:8080/parking/parkcar/automated?amountOfCars=CAR_AMOUNT </li>
</ul>
