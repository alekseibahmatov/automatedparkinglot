package com.test.automatedparkinglot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomatedParkingLotApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomatedParkingLotApplication.class, args);
	}

}
