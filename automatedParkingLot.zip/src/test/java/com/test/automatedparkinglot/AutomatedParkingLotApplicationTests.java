package com.test.automatedparkinglot;

//import org.assertj.core.api.Assert;
//import static org.hamcrest.CoreMatchers.*;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
class AutomatedParkingLotApplicationTests {

	@Test
	void contextLoads() {

	}

}
